package assitedpracticeproject;

public class callmethod {
	int val=200;
	int operation(int val) {
		val=val*10/100;
		return(val);
	}
	public static void main(String[] args) {
		callmethod c=new callmethod();
		System.out.println("value before" +c.val);
		c.operation(100);
		System.out.println("after "+c.val);
	}

}
