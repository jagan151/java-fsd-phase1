package assitedpracticeproject;

public class constructor {

	int empid;
	String empname;
	float salary;
	String departement;
	public constructor() {
		empid=2345;
		empname="varun";
		departement="accounts";
		salary=35000;
	}
	
	public constructor(int empid,String empname,String departement,float salary) {
		this.empid=empid;
		this.empname=empname;
		this.departement=departement;
		this.salary=salary;
		
		
	}
	void display() {
		System.out.println("id "+empid);
		System.out.println("name "+empname);
		System.out.println("departement "+departement);
		System.out.println("salary "+salary);
		System.out.println();
	}
	public static void main(String[] args) {
		constructor c = new constructor();
		constructor c1=new constructor(2233,"venky","finanace",45000);
		c.display();
		c1.display();
	}
}
