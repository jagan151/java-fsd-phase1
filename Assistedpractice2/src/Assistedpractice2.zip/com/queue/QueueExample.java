package com.queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
	public static void main(String[] args) {
		Queue<String> locationQueue= new LinkedList<String>();
		
		locationQueue.add("Nudurupadu");
		locationQueue.add("kandrika");
		locationQueue.add("merikapudi");
		locationQueue.add("satuluru");
		locationQueue.add("jonalagada");
		locationQueue.add("vemavaram");
		
		System.out.println("Queue is : "+locationQueue);
		
		
		//find head of queue
		System.out.println("Head of Queue: "+locationQueue.peek());
		
		locationQueue.remove();
		
		System.out.println("After Removing Head: "+locationQueue);
		
	}


}
