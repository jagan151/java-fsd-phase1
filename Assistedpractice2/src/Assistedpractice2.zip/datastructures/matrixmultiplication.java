package datastructures;

public class matrixmultiplication {
	public static void main(String[] args) {
		int m1[][]= {{1,2,3},{4,5,6}};
		int m2[][]= {{5,1},{3,7},{4,0}};
		int r[][]=new int[2][2];
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<2;j++) {
				for(int k=0;k<3;k++) {
					 r[i][j]=r[i][j] + m1[i][k]*m2[k][j];
					 
				}
			}
		}
		for(int i=0;i<2;i++) {
			for(int j=0;j<2;j++) {
				System.out.println(r[i][j] + " ");
			}
			System.out.println();
		}
	}
}	