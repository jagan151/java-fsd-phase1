package sort;

public class selectionsort {
	public static void main(String[] args) {
		int arr[]= {1,7,3,5,4,8,0};
		int x=arr.length;
		selectionSort(arr);
		for(int r:arr) {
			System.out.println(r +"\t ");
		}
	}

	public static void selectionSort(int arr[]) {
		for(int i=0;i<arr.length;i++) {
			int index=i;
			for(int j=i+1;j<arr.length;j++) {
				if(arr[j]<arr[index]) {
					 index = j;
				}
			}
				int n=arr[index];
				arr[index]=arr[i];
				arr[i]=n;
				 for(int x:arr){
		            	System.out.print(x+",");   
		            } System.out.println(); 
				
}
		}
		
		
	}

