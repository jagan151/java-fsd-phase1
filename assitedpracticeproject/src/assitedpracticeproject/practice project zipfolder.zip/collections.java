package assitedpracticeproject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;

public class collections {
	public static void main(String[] args) {
		System.out.println("arraylist");
		ArrayList<String> list=new ArrayList<String>();
		list.add("guntur");
		list.add("city");
		System.out.println(list);
		System.out.println();
		
		
		//vector
		System.out.println("vector");
		Vector<Integer> pet = new Vector<Integer>();
		pet.add(34);
		pet.add(45);
		System.out.println(pet);
		System.out.println();
		
		
		
		//linkedlist
		LinkedList<String> names = new LinkedList<String>();
		System.out.println("linkedlist");
		names.add("veeru");
		names.add("gopal");
		System.out.println(names);
		System.out.println();
		Iterator<String>itr=names.iterator();
		while(itr.hasNext());
		System.out.println(itr.next());
		System.out.println();
		
		
		//hashset
		HashSet<Integer> set = new HashSet<Integer>();
		System.out.println("hashset");
		set.add(65);
		set.add(45);
		set.add(75);
		System.out.println(set);
		System.out.println();
		
		
		//linkedhashset
		LinkedHashSet<Integer> set2 = new LinkedHashSet<Integer>();
		System.out.println("linkedhashset");
		set2.add(32);
		set2.add(98);
		set2.add(12);
		System.out.println(set2);
		
		
		
	}

}
