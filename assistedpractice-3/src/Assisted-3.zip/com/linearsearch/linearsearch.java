package com.linearsearch;

import java.util.Scanner;

public class linearsearch {
	public static void main(String[] args) {
		int arr[]= {23,12,1,45,82};
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number to be searched : ");
		int n=sc.nextInt();
		int result=linearing(arr,n);
				if(result==-1) {
					System.out.println("no element found");
				}
				else {
					System.out.println("the element found at " +result+ "the element searched is " +arr[result]);
				}
				
	}

	public static int linearing(int arr[],int n) {
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==n) {
				return i;
			}
		}
		return-1;
	}

}

