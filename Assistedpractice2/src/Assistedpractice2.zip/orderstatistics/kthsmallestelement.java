package orderstatistics;

import java.util.Arrays;

public class kthsmallestelement {
	public static int kthsmall(Integer[] arr,int k) {
		Arrays.sort(arr);
		return arr[k-1];
	}
		public static void main(String[] args) {
			Integer arr[]= {21,45,89,56,23,44};
			int k=4;
			System.out.println("the 4th smallest element :" +kthsmall(arr,k));
			
		}
	}


