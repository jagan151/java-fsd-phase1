package com.binarysearch;

import java.util.Arrays;

public class exponentialsearch {
	public static void main(String[] args) {
		int arr[]= {4,7,12,46,0,5};
		int key=0;
		int result=exponentialSearch(arr,key,arr.length);
		if(result<0) {
			System.out.println("element not found");
		}
		else {
			System.out.println("the element is aat index : "+result+"  ,the key is " +arr[result]);
		}
	}

	private static int exponentialSearch(int[] arr, int key, int length) {
		if(arr[0]==key) {
			return 0;
		}
		int i=1;
		while(i<length && arr[i]<=key) {
			i=i*2;
		}
		return Arrays.binarySearch(arr,i/2,Math.min(i, length),key);
	}

}

