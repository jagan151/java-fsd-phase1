package com.binarysearch;

public class BinearySearch {
	 public static void main(String[] args) {
	        int arr[] = {3,6,9,12,15};
	        
	        int key=9;
	        
	        int arrLength=arr.length;
	        
	        try {
				
			} catch (Exception e) {
				// TODO: handle exception
			} 
	        	binarySearch(arr,0,key,arrLength);
	        }
	       
	    
	    private static void binarySearch(int[] arr, int lb, int key, int ub) {
	        
	        int midValue= (lb+ub)/2;
	        
	        while(lb<=ub) {
	            
	            if(arr[midValue]<key)
	            {
	                lb= midValue+1;
	            }
	            else if(arr[midValue]==key)
	            {
	                System.out.println("Element found at index: "+midValue);
	                break;
	            }
	            else {
	                ub=midValue-1;
	            }
	            midValue=(lb+ub)/2;
	        }
	        if(lb>ub) {
	            System.out.println("Element Not Found");
	        }
	        
	    }
	}



