package assitedpracticeproject;

public class overloadmethod {
	public void area(int a,int b) {
		System.out.println("area of triangle "+(0.5*a*b));
	}
	public void area(int r) {
		System.out.println("area of circle" +(3.14*r*r));
	}
public static void main(String args[]) {
	overloadmethod x=new overloadmethod();
	x.area(10,3);
	x.area(4);
	}
}
